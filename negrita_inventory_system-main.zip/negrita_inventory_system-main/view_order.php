<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Connect to database
$conn = new mysqli("localhost", "root", "", "inventory_negrita");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch admin name
$stmt = $conn->prepare("SELECT admin_fname, admin_mname, admin_lname FROM admin_signup WHERE admin_id = ?");
$stmt->bind_param("i", $_SESSION['admin_id']);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();

$fullName = $admin ? $admin['admin_fname']: "Admin";

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ORDER MANAGEMENT</title>
    <link rel="stylesheet" type="text/css" href="CSS/admin_dashboard.css?v=<?= time(); ?>" />
    <link rel="stylesheet" type="text/css" href="CSS/orders_ui.css?v=<?= time(); ?>" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <script src="https://use.fontawesome.com/0c7a3095b5.js"></script>
    

  </head>

  <body>

    <div id="dashboardMainContainer">

      <!-- SIDEBAR -->
      <?php include('partials/sidebar.php'); ?>
      <!-- SIDEBAR -->

        <div class="dashboard_content_container" id="dashboard_content_container">

          <!-- TOP NAVBAR -->
          <?php include('partials/topnav.php') ?>
          <!-- TOP NAVBAR -->

            <div class="dashboard_content">
                          <div class="dashboard_content_main">
                <div class="container-fluid py-4">

                <!-- Page Header -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="col-12">
                                <h1 class="fw-bold" style="color: #6a0000;"><i class="bi bi-box-fill me-2"></i>ORDER LIST</h1>
                                
                            </div>
                            
                        </div>
                    </div>
                </div>

                 <!-- Modern Search and Filter Section -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="search-container">
                            <!-- Date Range Filter -->
                            <div class="date-filter-row">
                                <div class="date-input-group">
                                    <input type="date" class="date-input" id="dateFrom" placeholder="mm/dd/yyyy">
                                </div>
                                <div class="date-input-group">
                                    <input type="date" class="date-input" id="dateTo" placeholder="mm/dd/yyyy">
                                </div>
                                <div class="status-filter-group">
                                    <select class="status-filter" id="statusFilter">
                                        <option value="">All Status</option>
                                        <option value="pending">Pending</option>
                                        <option value="processing">Processing</option>
                                        <option value="completed">Completed</option>
                                        <option value="cancelled">Cancelled</option>
                                    </select>
                                </div>
                                <button class="filter-btn" id="filterBtn" 
                                        data-bs-toggle="tooltip" 
                                        data-bs-placement="top" 
                                        title="Filter">
                                    <i class="bi bi-funnel"></i> 
                                </button>
                                <button class="clear-btn" id="clearBtn"
                                        data-bs-toggle="tooltip" 
                                        data-bs-placement="top" 
                                        title="Clear">
                                    <i class="bi bi-arrow-clockwise"></i>
                                </button>
                            </div>
                            
                            <!-- Search Bar -->
                            <div class="position-relative">
                                <input type="text" class="form-control search-input" id="searchInput" 
                                       placeholder="Search by orderID or customer name...">
                            </div>
                        </div>
                    </div>
                </div>

                
                <!-- Orders List -->
                <div class="row">
                    <div class="col-12">
                        <div class="card shadow-sm">
                          
                            <div class="card-body" style="background-color: #fcfcfcff;">
                                <div id="ordersContainer">
                                    <!-- Orders will be loaded here -->
                                    <div class="text-center py-5">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="visually-hidden">Loading...</span>
                                        </div>
                                        <div class="mt-3">Loading orders...</div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Pagination Controls -->
                            <div class="card-footer bg-light">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="text-muted">
                                        <small id="paginationInfo">Showing 0 - 0 of 0 orders</small>
                                    </div>
                                    <nav aria-label="Orders pagination">
                                        <ul class="pagination pagination-sm mb-0" id="paginationControls">
                                            <li class="page-item disabled">
                                                <a class="page-link" href="#" onclick="loadOrders(currentPage - 1)">
                                                    <i class="bi bi-chevron-left"></i> Previous
                                                </a>
                                            </li>
                                            <li class="page-item active">
                                                <a class="page-link" href="#">1</a>
                                            </li>
                                            <li class="page-item disabled">
                                                <a class="page-link" href="#" onclick="loadOrders(currentPage + 1)">
                                                    Next <i class="bi bi-chevron-right"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            </div>
        </div>
    </div>

<!-- Order Details Modal -->
    <div class="modal fade" id="orderDetailsModal" tabindex="-1" aria-labelledby="orderDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header" style="background: linear-gradient(135deg, #410101, #5e0202); color: white;">
                    <h5 class="modal-title" id="orderDetailsModalLabel">
                        <i class="bi bi-receipt"></i> Order Details
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="orderDetailsContent">
                    <!-- Order details will be loaded here -->
                    <div class="text-center py-5">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <div class="mt-3">Loading order details...</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Close
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Update Status Modal -->
    <div class="modal fade" id="updateStatusModal" tabindex="-1" aria-labelledby="updateStatusModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header" style="background: linear-gradient(135deg, #ffc107, #ffcd39); color: #212529;">
                    <h5 class="modal-title" id="updateStatusModalLabel">
                        <i class="bi bi-pencil-square"></i> Update Order Status
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="newStatus" class="form-label fw-bold">Select New Status</label>
                        <select class="form-select" id="newStatus">
                            <option value="pending">Pending</option>
                            <option value="processing">Processing</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i>
                        <strong>Note:</strong> Changing the status will update the order and notify relevant parties.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Cancel
                    </button>
                    <button type="button" class="btn btn-primary" onclick="updateOrderStatus()" style="background: #410101; border-color: #410101;">
                        <i class="bi bi-check-circle"></i> Update Status
                    </button>
                </div>
            </div>
        </div>
    </div>





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
<!-- Include responsive sidebar functionality -->
    <script src="sidebar-drawer.js"></script>

    <script>
      let currentOrderId = null;
      let currentPage = 1;
      let totalPages = 1;
      let totalOrders = 0;
      const ordersPerPage = 10;
      
      // Load orders and statistics when page loads
      document.addEventListener('DOMContentLoaded', function() {
          loadOrders();
          loadOrderStatistics();
          
          // Initialize Bootstrap tooltips
          var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
          var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
              return new bootstrap.Tooltip(tooltipTriggerEl);
          });
          
          // Add event listeners for search input with debounce
          let searchTimeout;
          document.getElementById('searchInput').addEventListener('input', function() {
              clearTimeout(searchTimeout);
              searchTimeout = setTimeout(() => {
                  currentPage = 1;
                  loadOrders();
              }, 300); // 300ms delay
          });
          
          // Date range filter functionality
          document.getElementById('filterBtn').addEventListener('click', function() {
              currentPage = 1;
              loadOrders();
          });
          
          // Status filter functionality
          document.getElementById('statusFilter').addEventListener('change', function() {
              currentPage = 1;
              loadOrders();
          });
          
          // Clear filters functionality
          document.getElementById('clearBtn').addEventListener('click', function() {
              document.getElementById('dateFrom').value = '';
              document.getElementById('dateTo').value = '';
              document.getElementById('searchInput').value = '';
              document.getElementById('statusFilter').value = '';
              
              currentPage = 1;
              loadOrders();
          });
          
          // Auto-refresh orders every 30 seconds to catch cancellations from distributors
          setInterval(function() {
              loadOrders();
              loadOrderStatistics();
          }, 30000);
      });
      
      // Load order statistics
      function loadOrderStatistics() {
          fetch('get_order_stats.php')
              .then(response => response.json())
              .then(data => {
                  if (data.success) {
                      updateStatisticsCards(data.stats);
                  }
              })
              .catch(error => {
                  console.error('Error loading statistics:', error);
              });
      }
      
      // Update statistics cards
      function updateStatisticsCards(stats) {
          const cards = document.querySelectorAll('#statsCards .card h4');
          if (cards.length >= 5) {
              cards[0].textContent = stats.total || '0';
              cards[1].textContent = stats.completed || '0';
              cards[2].textContent = stats.processing || '0';
              cards[3].textContent = stats.pending || '0';
              cards[4].textContent = stats.cancelled || '0';
          }
      }
      
      // Load orders function
      function loadOrders(page = 1) {
          currentPage = page;
          const container = document.getElementById('ordersContainer');
          container.innerHTML = `
              <div class="text-center py-5">
                  <div class="spinner-border text-primary" role="status">
                      <span class="visually-hidden">Loading...</span>
                  </div>
                  <div class="mt-3">Loading orders...</div>
              </div>
          `;
          
          // Build query parameters
          const params = new URLSearchParams();
          const searchTerm = document.getElementById('searchInput').value;
          const dateFrom = document.getElementById('dateFrom').value;
          const dateTo = document.getElementById('dateTo').value;
          const statusFilter = document.getElementById('statusFilter').value;
          
          if (searchTerm) params.append('search', searchTerm);
          if (dateFrom) params.append('date_from', dateFrom);
          if (dateTo) params.append('date_to', dateTo);
          if (statusFilter) params.append('status', statusFilter);
          params.append('page', page);
          params.append('limit', ordersPerPage);
          
          fetch(`fetch_orders.php?${params.toString()}`)
              .then(response => response.json())
              .then(data => {
                  if (data.success) {
                      totalOrders = data.pagination.total || 0;
                      totalPages = data.pagination.totalPages || 1;
                      displayOrders(data.orders);
                      updatePaginationControls();
                  } else {
                      container.innerHTML = `
                          <div class="text-center py-5">
                              <i class="bi bi-inbox" style="font-size: 4rem; color: #ccc;"></i>
                              <h4 class="text-muted mt-3">No orders found</h4>
                              <p class="text-muted">${data.message || 'Try adjusting your filters to see more results.'}</p>
                          </div>
                      `;
                      updatePaginationControls();
                  }
              })
              .catch(error => {
                  console.error('Error:', error);
                  container.innerHTML = `
                      <div class="alert alert-danger text-center">
                          <i class="bi bi-exclamation-triangle"></i>
                          <strong>Error:</strong> An error occurred while loading orders. Please try again.
                      </div>
                  `;
                  updatePaginationControls();
              });
      }
      
      // Display orders function with modern list design
      function displayOrders(orders) {
          const container = document.getElementById('ordersContainer');
          
          if (orders.length === 0) {
              container.innerHTML = `
                  <div class="text-center py-5">
                      <i class="bi bi-inbox" style="font-size: 4rem; color: #ccc;"></i>
                      <h4 class="text-muted mt-3">No orders found</h4>
                      <p class="text-muted">Try adjusting your filters to see more results.</p>
                  </div>
              `;
              return;
          }
          
          let ordersHtml = '<div class="orders-list">';
          orders.forEach(order => {
              const statusClass = order.status.toLowerCase();
              const statusIcon = getStatusIcon(order.status);
              
              ordersHtml += `
                  <div class="order-item ${statusClass}">
                      <div class="order-left">
                          <div class="order-id">
                              <i class="bi bi-receipt"></i>
                              #${order.order_id}
                          </div>
                          
                          <div class="customer-info">
                              <div class="customer-name">
                                  <i class="bi bi-person-fill"></i>
                                  ${order.customer_name}
                              </div>
                              <div class="customer-contact">
                                  <i class="bi bi-telephone"></i>
                                  ${order.customer_contact || 'N/A'}
                              </div>
                          </div>
                          
                          <div class="order-amount">
                              ₱${parseFloat(order.total_amount_raw).toLocaleString('en-US', {minimumFractionDigits: 2})}
                          </div>
                      </div>
                      
                      <div class="order-right">
                          <div class="order-status ${statusClass}">
                              <i class="bi bi-${statusIcon}"></i>
                              ${order.status}
                          </div>
                          
                          <div class="order-date">
                              <i class="bi bi-calendar3"></i>
                              ${new Date(order.created_at).toLocaleDateString()}
                              <br>
                              <small class="text-muted">
                                  <i class="bi bi-clock"></i>
                                  ${new Date(order.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                              </small>
                          </div>
                          
                          <div class="order-actions">
                              <button class="action-btn view" onclick="viewOrderDetails(${order.order_id})" title="View Details">
                                  <i class="bi bi-eye"></i>
                              </button>
                              <button class="action-btn edit" onclick="showUpdateStatusModal(${order.order_id}, '${order.status}')" title="Update Status">
                                  <i class="bi bi-pencil"></i>
                              </button>
                          </div>
                      </div>
                  </div>
              `;
          });
          ordersHtml += '</div>';
          
          container.innerHTML = ordersHtml;
      }
      
      // Clear filters function
      function clearFilters() {
          document.getElementById('searchInput').value = '';
          document.getElementById('dateFrom').value = '';
          document.getElementById('dateTo').value = '';
          currentPage = 1;
          loadOrders();
      }
      
      // Update pagination controls
      function updatePaginationControls() {
          const paginationInfo = document.getElementById('paginationInfo');
          const paginationControls = document.getElementById('paginationControls');
          
          // Update info text
          const startItem = totalOrders === 0 ? 0 : (currentPage - 1) * ordersPerPage + 1;
          const endItem = Math.min(currentPage * ordersPerPage, totalOrders);
          paginationInfo.textContent = `Showing ${startItem} - ${endItem} of ${totalOrders} orders`;
          
          // Build pagination controls
          let paginationHtml = '';
          
          // Previous button
          const prevDisabled = currentPage <= 1 ? 'disabled' : '';
          paginationHtml += `
              <li class="page-item ${prevDisabled}">
                  <a class="page-link" href="#" data-page="${currentPage - 1}" ${prevDisabled ? 'tabindex="-1"' : ''}>
                      <i class="bi bi-chevron-left"></i> Previous
                  </a>
              </li>
          `;
          
          // Page numbers
          const maxVisiblePages = 5;
          let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
          let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
          
          // Adjust start page if we're near the end
          if (endPage - startPage + 1 < maxVisiblePages) {
              startPage = Math.max(1, endPage - maxVisiblePages + 1);
          }
          
          // Add page numbers
          for (let i = startPage; i <= endPage; i++) {
              const active = i === currentPage ? 'active' : '';
              paginationHtml += `
                  <li class="page-item ${active}">
                      <a class="page-link" href="#" data-page="${i}">${i}</a>
                  </li>
              `;
          }
          
          // Next button
          const nextDisabled = currentPage >= totalPages ? 'disabled' : '';
          paginationHtml += `
              <li class="page-item ${nextDisabled}">
                  <a class="page-link" href="#" data-page="${currentPage + 1}" ${nextDisabled ? 'tabindex="-1"' : ''}>
                      Next <i class="bi bi-chevron-right"></i>
                  </a>
              </li>
          `;
          
          paginationControls.innerHTML = paginationHtml;
          
          // Add event listeners to pagination links
          paginationControls.querySelectorAll('a.page-link').forEach(link => {
              link.addEventListener('click', function(e) {
                  e.preventDefault();
                  const page = parseInt(this.getAttribute('data-page'));
                  if (!isNaN(page) && page >= 1 && page <= totalPages && page !== currentPage) {
                      changePage(page);
                  }
              });
          });
      }
      
      // Change page function
      function changePage(page) {
          if (page < 1 || page > totalPages || page === currentPage) {
              return false;
          }
          loadOrders(page);
          return false;
      }
      
      // View order details function
      function viewOrderDetails(orderId) {
          currentOrderId = orderId;
          const modalContent = document.getElementById('orderDetailsContent');
          modalContent.innerHTML = `
              <div class="text-center py-5">
                  <div class="spinner-border text-primary" role="status">
                      <span class="visually-hidden">Loading...</span>
                  </div>
                  <div class="mt-3">Loading order details...</div>
              </div>
          `;
          
          const modal = new bootstrap.Modal(document.getElementById('orderDetailsModal'));
          modal.show();
          
          fetch(`fetch_order_details.php?order_id=${orderId}`)
              .then(response => response.json())
              .then(data => {
                  if (data.success) {
                      displayOrderDetails(data.order, data.items);
                  } else {
                      modalContent.innerHTML = `
                          <div class="alert alert-danger">
                              <i class="bi bi-exclamation-triangle"></i>
                              <strong>Error:</strong> ${data.message || 'Failed to load order details'}
                          </div>
                      `;
                  }
              })
              .catch(error => {
                  console.error('Error:', error);
                  modalContent.innerHTML = `
                      <div class="alert alert-danger">
                          <i class="bi bi-exclamation-triangle"></i>
                          <strong>Error:</strong> An error occurred while loading order details
                      </div>
                  `;
              });
      }
      
      // Display order details function with modern styling
      function displayOrderDetails(order, items) {
          const modalContent = document.getElementById('orderDetailsContent');
          const statusColor = getStatusColor(order.status);
          const statusIcon = getStatusIcon(order.status);
          
          let itemsHtml = '';
          let totalAmount = 0;
          items.forEach((item, index) => {
              const itemTotal = parseFloat(item.total_price_raw);
              totalAmount += itemTotal;
              itemsHtml += `
                  <tr>
                      <td class="text-center">${index + 1}</td>
                      <td>${item.product_name}</td>
                      <td class="text-center">${item.quantity}</td>
                      <td class="text-end">₱${parseFloat(item.unit_price_raw).toLocaleString('en-US', {minimumFractionDigits: 2})}</td>
                      <td class="text-end">₱${itemTotal.toLocaleString('en-US', {minimumFractionDigits: 2})}</td>
                      <td class="text-center">
                          <span class="badge bg-info">${item.current_stock || 'N/A'}</span>
                      </td>
                  </tr>
              `;
          });
          
          modalContent.innerHTML = `
              <!-- Order Header -->
              <div class="row mb-4">
                  <div class="col-md-4">
                      <div class="card border-primary h-100">
                          <div class="card-header bg-primary text-white">
                              <h6 class="mb-0"><i class="bi bi-person"></i> Customer Information</h6>
                          </div>
                          <div class="card-body">
                              <p class="mb-2"><strong>Name:</strong> ${order.customer_name}</p>
                              <p class="mb-2"><strong>Contact:</strong> ${order.customer_contact || 'N/A'}</p>
                              <p class="mb-0"><strong>Address:</strong> ${order.customer_address || 'N/A'}</p>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="card border-${statusColor} h-100">
                          <div class="card-header bg-${statusColor} text-white">
                              <h6 class="mb-0"><i class="bi bi-receipt"></i> Order Information</h6>
                          </div>
                          <div class="card-body">
                              <p class="mb-2"><strong>Order ID:</strong> #${order.order_id}</p>
                              <p class="mb-2"><strong>Status:</strong> 
                                  <span class="badge bg-${statusColor}">
                                      <i class="bi bi-${statusIcon}"></i> ${order.status.toUpperCase()}
                                  </span>
                              </p>
                              <p class="mb-2"><strong>Created By:</strong> ${order.created_by}</p>
                              <p class="mb-2"><strong>Created:</strong> ${new Date(order.created_at).toLocaleDateString()}</p>
                              <p class="mb-0"><strong>Last Updated:</strong> ${new Date(order.updated_at).toLocaleDateString()}</p>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="card border-success h-100">
                          <div class="card-header bg-success text-light">
                              <h6 class="mb-0"><i class="bi bi-journal-text"></i> Order Notes</h6>
                          </div>
                          <div class="card-body">
                              <div class="p-2 bg-light border rounded" style="min-height: 100px; max-height: 150px; overflow-y: auto;">
                                  ${order.order_notes ? `<div class="text-dark">${order.order_notes}</div>` : '<span class="text-muted fst-italic">No notes added for this order</span>'}
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              
              <!-- Order Items -->
              <div class="card">
                  <div class="card-header bg-light">
                      <h6 class="mb-0"><i class="bi bi-list-ul"></i> Order Items</h6>
                  </div>
                  <div class="card-body p-0">
                      <div class="table-responsive">
                          <table class="table table-hover mb-0">
                              <thead class="table-light">
                                  <tr>
                                      <th class="text-center">#</th>
                                      <th>Product Name</th>
                                      <th class="text-center">Quantity</th>
                                      <th class="text-end">Unit Price</th>
                                      <th class="text-end">Total Price</th>
                                      <th class="text-center">Stock Available</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  ${itemsHtml}
                              </tbody>
                          </table>
                      </div>
                  </div>
                  <div class="card-footer bg-light">
                      <div class="row">
                          <div class="col-md-6">
                              <p class="mb-0 text-muted">Total Items: ${items.length}</p>
                          </div>
                          <div class="col-md-6 text-end">
                              <h5 class="mb-0 text-success">
                                  <strong>Total Amount: ₱${totalAmount.toLocaleString('en-US', {minimumFractionDigits: 2})}</strong>
                              </h5>
                          </div>
                      </div>
                  </div>
              </div>
          `;
          
          document.getElementById('orderDetailsModalLabel').innerHTML = `
              <i class="bi bi-receipt"></i> Order #${order.order_id} Details
          `;
      }
      
      // Show update status modal
      function showUpdateStatusModal(orderId, currentStatus) {
          currentOrderId = orderId;
          document.getElementById('newStatus').value = currentStatus;
          const modal = new bootstrap.Modal(document.getElementById('updateStatusModal'));
          modal.show();
      }
      
      // Update order status function
      function updateOrderStatus() {
          if (!currentOrderId) return;
          
          const newStatus = document.getElementById('newStatus').value;
          
          // Show loading
          const updateBtn = event.target;
          const originalText = updateBtn.innerHTML;
          updateBtn.innerHTML = '<i class="spinner-border spinner-border-sm"></i> Updating...';
          updateBtn.disabled = true;
          
          fetch('update_order_status.php', {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                  order_id: currentOrderId,
                  status: newStatus
              })
          })
          .then(response => response.json())
          .then(data => {
              if (data.success) {
                  Swal.fire({
                      icon: 'success',
                      title: 'Success!',
                      text: 'Order status updated successfully!',
                      timer: 1500,
                      showConfirmButton: false
                  }).then(() => {
                      // Close modal and reload orders
                      const modal = bootstrap.Modal.getInstance(document.getElementById('updateStatusModal'));
                      modal.hide();
                      loadOrders();
                      loadOrderStatistics();
                  });
              } else {
                  Swal.fire({
                      icon: 'error',
                      title: 'Error',
                      text: data.message || 'Failed to update order status'
                  });
              }
          })
          .catch(error => {
              console.error('Error:', error);
              Swal.fire({
                  icon: 'error',
                  title: 'Error',
                  text: 'An error occurred while updating order status'
              });
          })
          .finally(() => {
              // Restore button
              updateBtn.innerHTML = originalText;
              updateBtn.disabled = false;
          });
      }
      
      // Helper function to get status color
      function getStatusColor(status) {
          switch(status.toLowerCase()) {
              case 'pending': return 'warning';
              case 'processing': return 'info';
              case 'completed': return 'success';
              case 'cancelled': return 'danger';
              default: return 'secondary';
          }
      }
      
      // Helper function to get status icon
      function getStatusIcon(status) {
          switch(status.toLowerCase()) {
              case 'pending': return 'clock';
              case 'processing': return 'arrow-clockwise';
              case 'completed': return 'check-circle';
              case 'cancelled': return 'x-circle';
              default: return 'question-circle';
          }
      }
      
      // Prevent browser back navigation
      history.pushState(null, null, location.href);
      window.onpopstate = function () {
        history.go(1);
      };
    </script>

   




    

    
    
  </body>
</html>
