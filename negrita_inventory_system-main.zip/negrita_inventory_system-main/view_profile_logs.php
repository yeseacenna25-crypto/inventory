<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Connect to database
$conn = new mysqli("localhost", "root", "", "inventory_negrita");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if admin_profile_logs table exists
$table_check = $conn->query("SHOW TABLES LIKE 'admin_profile_logs'");
$logs_exist = $table_check->num_rows > 0;

$logs = [];
if ($logs_exist) {
    // Fetch profile change logs for current admin
    $stmt = $conn->prepare("
        SELECT 
            apl.field_changed,
            apl.old_value,
            apl.new_value,
            apl.changed_at,
            apl.ip_address,
            CONCAT(a.first_name, ' ', a.last_name) as changed_by_name
        FROM admin_profile_logs apl
        LEFT JOIN admin_signup a ON apl.changed_by = a.admin_id
    WHERE apl.admin_id = ?
        ORDER BY apl.changed_at DESC
        LIMIT 50
    ");
    
    $stmt->bind_param("i", $_SESSION['admin_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $logs[] = $row;
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Change Logs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .change-log {
            border-left: 4px solid #007bff;
            background-color: white;
            margin-bottom: 10px;
            padding: 15px;
            border-radius: 0 8px 8px 0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .field-name {
            font-weight: bold;
            color: #495057;
            text-transform: capitalize;
        }
        .old-value {
            background-color: #f8d7da;
            color: #721c24;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: monospace;
        }
        .new-value {
            background-color: #d4edda;
            color: #155724;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: monospace;
        }
        .timestamp {
            color: #6c757d;
            font-size: 0.9em;
        }
        .no-logs {
            text-align: center;
            padding: 40px;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3><i class="fa fa-history"></i> Profile Change Logs</h3>
            <button type="button" class="btn btn-secondary btn-sm" onclick="window.close()">
                <i class="fa fa-times"></i> Close
            </button>
        </div>

        <?php if (!$logs_exist): ?>
            <div class="alert alert-info">
                <i class="fa fa-info-circle"></i> 
                Profile logging is not enabled. No change history is available.
            </div>
        <?php elseif (empty($logs)): ?>
            <div class="no-logs">
                <i class="fa fa-clipboard-list fa-3x mb-3"></i>
                <h5>No Changes Recorded</h5>
                <p>Your profile hasn't been modified since logging was enabled.</p>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-12">
                    <?php foreach ($logs as $log): ?>
                        <div class="change-log">
                            <div class="d-flex justify-content-between align-items-start">
                                <div class="flex-grow-1">
                                    <div class="field-name mb-2">
                                        <i class="fa fa-edit"></i> 
                                        <?= ucfirst(str_replace('_', ' ', htmlspecialchars($log['field_changed']))) ?> Changed
                                    </div>
                                    
                                    <div class="mb-2">
                                        <small class="text-muted">From:</small>
                                        <span class="old-value">
                                            <?= $log['old_value'] ? htmlspecialchars($log['old_value']) : '<empty>' ?>
                                        </span>
                                        <br>
                                        <small class="text-muted">To:</small>
                                        <span class="new-value">
                                            <?= $log['new_value'] ? htmlspecialchars($log['new_value']) : '<empty>' ?>
                                        </span>
                                    </div>
                                    
                                    <div class="timestamp">
                                        <i class="fa fa-clock"></i>
                                        <?= date('F j, Y g:i A', strtotime($log['changed_at'])) ?>
                                        <?php if ($log['changed_by_name']): ?>
                                            by <?= htmlspecialchars($log['changed_by_name']) ?>
                                        <?php endif; ?>
                                        <?php if ($log['ip_address'] && $log['ip_address'] !== 'unknown'): ?>
                                            <span class="text-muted">(IP: <?= htmlspecialchars($log['ip_address']) ?>)</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="text-end">
                                    <?php
                                    $icon = match($log['field_changed']) {
                                            'profile_image' => 'fa-image',
                                            'distrib_profile_image' => 'fa-image',
                                            'staff_profile_image' => 'fa-image',
                                            'email' => 'fa-envelope',
                                            'phone' => 'fa-phone',
                                            'department' => 'fa-building',
                                            'position' => 'fa-briefcase',
                                            'bio' => 'fa-file-text',
                                            default => 'fa-user'
                                        };
                                    ?>
                                    <i class="fa <?= $icon ?> fa-lg text-muted"></i>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    
                    <?php if (count($logs) >= 50): ?>
                        <div class="alert alert-info text-center mt-3">
                            <i class="fa fa-info-circle"></i>
                            Showing latest 50 changes. Older changes may exist but are not displayed.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
      // Prevent browser back navigation
      history.pushState(null, null, location.href);
      window.onpopstate = function () {
        history.go(1);
      };
    </script>
</body>
</html>
