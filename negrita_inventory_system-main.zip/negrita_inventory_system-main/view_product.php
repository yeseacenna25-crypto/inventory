<?php
session_start();
// Connect to database
$conn = new mysqli("localhost", "root", "", "inventory_negrita");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$product = null;
if ($product_id > 0) {
    $stmt = $conn->prepare("SELECT product_id, product_name, category, quantity, price, description, product_image FROM products WHERE product_id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
    $stmt->close();
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Product</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Product Details</h2>
    <?php if ($product): ?>
        <div class="card" style="max-width: 400px;">
            <div class="card-body">
                <h5 class="card-title"><?php echo htmlspecialchars($product['product_name']); ?></h5>
                <p class="card-text">Category: <?php echo htmlspecialchars($product['category']); ?></p>
                <p class="card-text">Description: <?php echo htmlspecialchars($product['description']); ?></p>
                <p class="card-text">Price: ₱<?php echo number_format($product['price'], 2); ?></p>
                <p class="card-text">Quantity: <?php echo htmlspecialchars($product['quantity']); ?></p>
                <?php if (!empty($product['product_image'])): ?>
                    <img src="<?php echo 'uploads/' . htmlspecialchars($product['product_image']); ?>" class="img-thumbnail" width="200" alt="Product Image">
                <?php endif; ?>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-danger">Product not found.</div>
    <?php endif; ?>
</div>
<script>
    // Prevent browser back navigation
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
    };
</script>
</body>
</html>
